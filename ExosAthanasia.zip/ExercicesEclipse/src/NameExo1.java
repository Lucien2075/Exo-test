
public class NameExo1 {
	public static String string1 = "Hello ";
	public static String string2 = "Lucien ";
	public static String string3 = "Lucky ";
	
	public static void essai (String a, String b, String c) {
		System.out.println (c + b + a);
		
		
	}
			
	public static void main	(String[] args)	{
		essai(string1, string2, string3);
	}

}
