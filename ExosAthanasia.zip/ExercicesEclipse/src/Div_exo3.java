
public class Div_exo3 {
	
	public static 

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

/* 
3. Write a Java program to divide two numbers and print on the screen . 
Test Data : 
50/3
Expected Output :
16.6666667
*/