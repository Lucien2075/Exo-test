package ExoPierre;

public class ExoPierre1 {
	

	
	public static int div(int a, int b) {
		
		int div = a/b;
		System.out.println(div);
		return div;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		div(20,2);

	}

}
