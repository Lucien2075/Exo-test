
public class NameExo1_1 {
	
	
	public static void essai2 (String str1, String str2, String str3) {
		
	System.out.println(str1+str2+str3);	
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str1 = " Hello";
		String str2 = " Lucien";
		String str3 = " Lucky";
		
		essai2 (str1, str2, str3);
		
		
		
		
	}

	
	
}
