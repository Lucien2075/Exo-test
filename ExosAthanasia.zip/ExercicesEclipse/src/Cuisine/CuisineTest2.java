package Cuisine;

public class CuisineTest2 {
    
  

    //méthode bouffe 1
    
    public static boolean bouffeok(int cuisson, String aliment1, String aliment2) {
        if (cuisson>=30 && aliment1=="haricots verts" && aliment2=="blé") { // ATTENTION ! le signe == ne fonctionne pas toujours avec les Strings. On peut aussi utiliser aliment2.equals("blé")
            return true;
        }
        else {
            return false;
        }
    }
    
    //méthode bouffe 2
    
    public static boolean donnerbouffe(int cuisson, String aliment1, String aliment2) {    
        if (cuisson>=30 && aliment1=="haricots verts" && aliment2=="blé") {
        return true;
    } else {
        return false;
    }
    }
    
    //méthode main
    
    public static void main(String[] args) {
        
      
        
        boolean plat = bouffeok(30, "haricots verts", "blé");
        if (plat == true) {
            System.out.print("la bouffe est prête !");
        } else {
            System.out.print("ça cuit encore !");
        }
        
        //boolean service = donnerbouffe(30,"haricots verts", "blé" )
    }
    

}