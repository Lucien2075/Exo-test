package Cuisine;

public class CuisineTest {
    
    public static String bouffe (String a2, String a1, int temps) {
        
        
        String resultat;
        
        char et = '&';
        resultat = blé + et + haricotsVerts;
        
        return resultat;
        
        if (temps ≥ 30)&&((a1.equals ("blé"))&&(a2.equals("haricots verts")))
        		
        		{
			return-true; } 
        else {
				return false;}
		}
        
      
    }



boolean la;

la = bouffe ok (27, "blé", "haricots")


if(la==true ) {
	
	
    public static void main(String[] args) {
        
        
        System.out.println("le repas est prêt");

    }
    else {
    	
    	System.out.println("le repas n'est pas prêt");
    }

}