package Cuisine;

public class Cuisine {
    
    public static String bouffe (String ble, String haricotsVerts) {
        
        
        String resultat;
        
        char et = '&';
        resultat = ble + et + haricotsVerts;
        
        return resultat;
    }

    public static void main(String[] args) {
        
        
        String ble = "blé ";
        String haricotsVerts = " haricots verts";
        
        String resultat;
        resultat = bouffe (ble,haricotsVerts);
        System.out.println(resultat);

    }

}