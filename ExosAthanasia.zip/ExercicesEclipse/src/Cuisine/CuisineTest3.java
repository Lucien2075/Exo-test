package Cuisine;

public class CuisineTest3 {

	public static boolean bouffeOk (int cuisson , String aliment1, String aliment2)
	
	{
		if (cuisson >= 30 && aliment1=="haricots verts" && aliment2=="blé")
		{return true;
		}
	
	else {
		return false;
	}
	}
	
		
		public static boolean pasEncore (int cuisson, String aliment1, String aliment2)
		
		{
			if (cuisson >= 30 && aliment1=="haricots verts" && aliment2=="blé")
		
		{return true;
		}
	
	else {
		return false;
	}
		}
		
		 public static void main(String[] args) {
			 

		        boolean plat = bouffeOk(30, "haricots verts", "blé");
		        if (plat == true) {
		            System.out.print("la bouffe est prête !");
		        } else {
		            System.out.print("ça cuit encore !");
		        }
		        
		        //boolean service = donnerbouffe(30,"haricots verts", "blé" )
		    }
		    

		}

