
public class DivExo3 {
	
	
	public static void essai4div (double a, double b)
	{
		System.out.println(a/b);
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		essai4div (50, 3);
	}

}
