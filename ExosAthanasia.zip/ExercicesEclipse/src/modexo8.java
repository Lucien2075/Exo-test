
public class modexo8 {
	
	
	public static int a = 125;
	public static String b = " mod ";
	public static int c = 24;
	public static String d = " = ";
	public static int e = 5;
	
	public static void essai1 (int a, String b, int c, String d, int e) {
		System.out.println(a+b+c+d+e);
	}
			
			

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		essai1(a,b,c,d,e);
	}

}
