
public class SumExo2 {

	
	public static void essai3 (int a, int b, int c, int d, int e, int f)
	{
		System.out.println(a+b+c+d+e+f);
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		essai3 (74, 36, 5, 10, 15, 10);

	}

}



