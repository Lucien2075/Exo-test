package ateliers;

public class atelier1_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//12, 15, 13, 10, 8, 9, 13 et 14. */
		
		int[] tab = {12, 15, 13, 10, 8, 9, 13, 14};
		
		
		
		/* 2) Modifier le cinquième élément du tableau pour lui attribuer la valeur 5 et l’afficher.
		
		je déclare à nouveau la position 5 du tableau en attribuant une nouvelle valeur
		*/
           tab[4]=5;
	
           
           /*3) Afficher tous les éléments du tableau. /!\ Il est interdit d’utiliser une boucle !
           KEEP IT SIMPLE
/*
	/*  System.out.println(tab[0]);
		System.out.println(tab[1]);
		System.out.println(tab[2]);
		System.out.println(tab[3]);
		System.out.println(tab[4]);
		System.out.println(tab[5]);
		System.out.println(tab[6]);
		System.out.println(tab[7]); 

		
		*/
		
		
		/* 4) Afficher tous les éléments du tableau. /!\ La boucle “for” est obligatoire !
exemple : for(i=0; i<8; i++) {
			System.out.println("bonjour");
*/
		
	
		for(int pos=0; pos<8; pos++) {
			System.out.println(tab[pos]);
		}
		
		/*
		 5) Demander à l’utilisateur d’entrer un nombre entier 
		 et stocker sa valeur dans une variable nommée input.
		 */
		
		
		/* 
		
		import java.util.scanner
		
		
		déclarer  : scanner sc;
		
		créer instance :  sc = new scanner(System.in)
		
		*/
		
		
		
	}
	

}
