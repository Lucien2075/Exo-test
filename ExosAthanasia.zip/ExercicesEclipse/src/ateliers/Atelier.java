package ateliers;

public class Atelier {

	public static void main(String[] args) {
		/* TODO Auto-generated method stub
		// Dans cet exercice, on va travailler avec un tableau d’entiers appelé tab contenant les valeurs suivantes : 
			12, 15, 13, 10, 8, 9, 13 et 14. 
			
			- déclarer tableau
			- donner une taille au cadeau
			- initialiser les éléments du tableau
			
			*/
			
			int [] tab = new int [8];
			
		    tab [0]= 12;
			tab [1]= 15;
		    tab [2]= 13;
		    tab [3]= 10;
		    tab [4]= 8;
		    tab [5]= 9;
		    tab [6]= 13;
		    tab [7]= 14;



	}

}
