import java.util.Scnanner;

public class AtelierScanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//déclarer le Scanner
		System.out.println("entre un entier");
		//Scanner <nom du scnanner>;
		Scanner sc;
		//créer une instance de Scanner avec le mot-clé new
		//<nom du scnanner> = new Scanner(System.in);
		sc = new Scanner(System.in);
		//stock la valeur du scanner
		int input = sc.System.out.println(input);nextInt();
		System.out.println(input);
		
		
		
		
		
		
	}

}
