package ateliers;

public class atelier1_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//12, 15, 13, 10, 8, 9, 13 et 14. */
		
		int[] tab = {12, 15, 13, 10, 8, 9, 13, 14};
		
	
		System.out.println(tab[7]);
	}
	

}
