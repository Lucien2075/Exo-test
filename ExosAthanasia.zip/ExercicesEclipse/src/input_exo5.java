
public class input_exo5 {
	
	public static int a = 25;
	public static String b = "x";
	public static int c = 5;
	public static String d = "=";
	public static int e = 125;
	
	
	public static void essai1 (int a, String b, int c, String d, int e)
	{ 
		System.out.println(a+b+c+d+e);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
essai1 (a,b,c,d,e);
	}

}
