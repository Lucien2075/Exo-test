
public class exo3_1 {
	double a;
	double b;
	double div;
	public static double calcul(double a, double b) {
		double div;
		div = a/b;
		System.out.println(div);
		return div;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calcul(5, 3);
	}

}


/*
a. -5 + 8 * 6
b. (55+9) % 9 
c. 20 + -3*5 / 8 
d. 5+15/3*2-8%3
*/