
public class multiopexo4 {
	
	public static int a = -5;
	public static int b = 8;
	public static int c = 6;	
	public static int d = 55;
	public static int e = 9;
	public static int f = 9;
	public static int g = 20;
	public static int h = -3;
	public static int i = 5;
    public static int j = 8;
    public static int k = 5;	
    public static int l = 15;
    public static int m = 3;
    public static int n = 2;
    public static int o = 8;
    public static int p = 3;
    														
	
	public static void essai1  (int a1, int b1, int c1) {
		System.out.println(a1+b1*c1);
			
	}
	public static void essai2 (int a1, int b1, int c1) {
	System.out.println((a1+b1)%c1);
	}
	public static void essai3 (int a1, int b1, int c1, int d1) {
		System.out.println(a1+b1*c1/d1);
	}
	public static void essai4 (int a1, int b1, int c1, int d1, int e1, int f1) {
	System.out.println(a1+b1/c1*d1-e1%f1);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		essai1 (a,b,c);
		essai2 (d,e,f);
		essai3 (g,h,i,j);
		essai4 (k,l,m,n,o,p);
	}

}
